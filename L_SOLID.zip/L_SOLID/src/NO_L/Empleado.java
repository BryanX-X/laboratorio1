package NO_L;

public abstract class Empleado {
    protected String nombre, departamento;

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public String getNombre() {
        return nombre;
    }

    public abstract double calcularBono();
}
