package NO_L;

public class Docente extends Empleado {

    @Override
    public double calcularBono() {
        return 200.0;
    }
}
