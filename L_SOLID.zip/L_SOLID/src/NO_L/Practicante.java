package NO_L;

public class Practicante extends Empleado {

    //cerebro del ejercicio: Practicante promete calcularBono() (porque hereda
    //de Empleado) pero en realidad NO puede cumplirlo. Al sustituir un Empleado
    //por un Practicante, el programa se rompe. Eso viola LSP.
    @Override
    public double calcularBono() {
        throw new UnsupportedOperationException("Los practicantes no reciben bono");
    }
}
