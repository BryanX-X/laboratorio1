package NO_L;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class NO_L {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        List<Empleado> empleados = new ArrayList<>();

        Docente docente = new Docente();
        docente.setNombre("Ana");
        empleados.add(docente);

        Practicante practicante = new Practicante();
        practicante.setNombre("Luis");
        empleados.add(practicante);

        int op;

        do {
            System.out.println("---Menu de opciones---");
            System.out.println("1.Calcular bono de todos los empleados.");
            System.out.println("2.Salir");
            System.out.println("ingrese una opcion:");
            op = sc.nextInt();

            switch (op) {
                case 1:
                    //al llegar al practicante, el programa se cae con una excepcion
                    for (Empleado e : empleados) {
                        System.out.println(e.getNombre() + " -> bono: " + e.calcularBono());
                    }
                    break;
                case 2:
                    System.out.println("saliendo del programa....");
                    break;
                default:
                    System.out.println("opcion incorrecta...");
            }

        } while (op != 2);
    }

}
