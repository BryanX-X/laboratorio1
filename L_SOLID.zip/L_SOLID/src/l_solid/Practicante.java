package l_solid;

//Practicante NO implementa Bonificable, porque no aplica para el.
//Así puede sustituir a Empleado sin romper nada, cumpliendo LSP.
public class Practicante extends Empleado {
}
