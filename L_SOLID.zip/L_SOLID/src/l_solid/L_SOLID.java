package l_solid;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class L_SOLID {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        List<Empleado> empleados = new ArrayList<>();

        Docente docente = new Docente();
        docente.setNombre("Ana");
        empleados.add(docente);

        Administrativo adm = new Administrativo();
        adm.setNombre("Carlos");
        empleados.add(adm);

        Practicante practicante = new Practicante();
        practicante.setNombre("Luis");
        empleados.add(practicante);

        int op;

        do {
            System.out.println("---Menu de opciones---");
            System.out.println("1.Mostrar datos de todos los empleados.");
            System.out.println("2.Calcular bono (solo a los que aplican).");
            System.out.println("3.Salir");
            System.out.println("ingrese una opcion:");
            op = sc.nextInt();

            switch (op) {
                case 1:
                    for (Empleado e : empleados) {
                        e.mostrarDatos();
                    }
                    break;
                case 2:
                    //cada empleado se puede sustituir sin romper el programa,
                    //solo se calcula el bono a quien realmente lo tiene
                    for (Empleado e : empleados) {
                        if (e instanceof Bonificable bonificable) {
                            System.out.println(e.getNombre() + " -> bono: " + bonificable.calcularBono());
                        } else {
                            System.out.println(e.getNombre() + " -> no recibe bono");
                        }
                    }
                    break;
                case 3:
                    System.out.println("saliendo del programa....");
                    break;
                default:
                    System.out.println("opcion incorrecta...");
            }

        } while (op != 3);
    }

}
