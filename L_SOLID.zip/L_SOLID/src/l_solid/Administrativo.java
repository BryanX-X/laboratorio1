package l_solid;

public class Administrativo extends Empleado implements Bonificable {

    @Override
    public double calcularBono() {
        return 100.0;
    }
}
