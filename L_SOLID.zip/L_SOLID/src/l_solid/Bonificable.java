package l_solid;

//Solo los empleados que REALMENTE reciben bono implementan esta interfaz.
public interface Bonificable {
    double calcularBono();
}
