package l_solid;

public class Docente extends Empleado implements Bonificable {

    @Override
    public double calcularBono() {
        return 200.0;
    }
}
