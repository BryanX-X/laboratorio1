package i_solid;

import java.util.Scanner;

public class I_SOLID {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Docente docente = new Docente();
        Practicante practicante = new Practicante();

        int op;

        do {
            System.out.println("---Menu de opciones---");
            System.out.println("1.Docente trabaja.");
            System.out.println("2.Practicante trabaja.");
            System.out.println("3.Calcular bono docente.");
            System.out.println("4.Docente asiste a reunion.");
            System.out.println("5.Salir");
            System.out.println("ingrese una opcion:");
            op = sc.nextInt();

            switch (op) {
                case 1:
                    docente.trabajar();
                    break;
                case 2:
                    practicante.trabajar();
                    break;
                case 3:
                    System.out.println("Bono: " + docente.calcularBono());
                    break;
                case 4:
                    docente.asistirReunion();
                    break;
                case 5:
                    System.out.println("saliendo del programa....");
                    break;
                default:
                    System.out.println("opcion incorrecta...");
            }

        } while (op != 5);
    }

}
