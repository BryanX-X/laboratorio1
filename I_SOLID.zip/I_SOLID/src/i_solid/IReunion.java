package i_solid;

public interface IReunion {
    void asistirReunion();
}
