package i_solid;

//Practicante solo implementa ITrabajador, porque IBonificable e IReunion
//no le aplican. Ya no esta obligado a implementar metodos que no puede cumplir.
public class Practicante implements ITrabajador {

    @Override
    public void trabajar() {
        System.out.println("Practicante haciendo tareas de apoyo...");
    }
}
