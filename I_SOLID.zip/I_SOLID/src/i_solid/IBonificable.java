package i_solid;

public interface IBonificable {
    double calcularBono();
}
