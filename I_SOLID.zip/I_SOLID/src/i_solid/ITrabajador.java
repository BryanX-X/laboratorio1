package i_solid;

public interface ITrabajador {
    void trabajar();
}
