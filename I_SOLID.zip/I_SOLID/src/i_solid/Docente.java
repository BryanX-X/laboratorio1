package i_solid;

public class Docente implements ITrabajador, IBonificable, IReunion {

    @Override
    public void trabajar() {
        System.out.println("Docente dictando clases...");
    }

    @Override
    public double calcularBono() {
        return 200.0;
    }

    @Override
    public void asistirReunion() {
        System.out.println("Docente asistiendo a reunion de facultad...");
    }
}
