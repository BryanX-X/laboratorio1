package NO_I;

//cerebro del ejercicio: interfaz "gorda" que obliga a implementar
//metodos que no le aplican a todos los tipos de empleado
public interface ITrabajador {
    void trabajar();
    double calcularBono();
    void asistirReunion();
}
