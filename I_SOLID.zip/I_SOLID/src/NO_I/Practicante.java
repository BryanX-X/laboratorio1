package NO_I;

public class Practicante implements ITrabajador {

    @Override
    public void trabajar() {
        System.out.println("Practicante haciendo tareas de apoyo...");
    }

    @Override
    public double calcularBono() {
        //no le aplica, pero la interfaz lo obliga a implementarlo
        throw new UnsupportedOperationException("Los practicantes no reciben bono");
    }

    @Override
    public void asistirReunion() {
        //tampoco le aplica
        throw new UnsupportedOperationException("Los practicantes no asisten a reuniones");
    }
}
