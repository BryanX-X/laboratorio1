package NO_I;

import java.util.Scanner;

public class NO_I {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Docente docente = new Docente();
        Practicante practicante = new Practicante();

        int op;

        do {
            System.out.println("---Menu de opciones---");
            System.out.println("1.Docente trabaja.");
            System.out.println("2.Practicante trabaja.");
            System.out.println("3.Calcular bono practicante (falla).");
            System.out.println("4.Salir");
            System.out.println("ingrese una opcion:");
            op = sc.nextInt();

            switch (op) {
                case 1:
                    docente.trabajar();
                    break;
                case 2:
                    practicante.trabajar();
                    break;
                case 3:
                    //esto lanza una excepcion, porque la interfaz obligo
                    //a Practicante a "prometer" algo que no puede cumplir
                    System.out.println(practicante.calcularBono());
                    break;
                case 4:
                    System.out.println("saliendo del programa....");
                    break;
                default:
                    System.out.println("opcion incorrecta...");
            }

        } while (op != 4);
    }

}
