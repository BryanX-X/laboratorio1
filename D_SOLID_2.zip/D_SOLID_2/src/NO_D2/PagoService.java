package NO_D2;

public class PagoService {
    private PasarelaPayPal pasarela;

    //cerebro del ejercicio: PagoService (clase de ALTO nivel) depende
    //DIRECTAMENTE de PasarelaPayPal (clase de BAJO nivel).
    //Si mañana quiero pagar con tarjeta, tengo que MODIFICAR esta clase.
    public PagoService() {
        pasarela = new PasarelaPayPal();
    }

    public void procesarPago(Pedido pedido) {
        pasarela.pagar(pedido);
    }
}
