package NO_D2;

import java.util.Scanner;

public class NO_D2 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Pedido pedido = new Pedido();
        int op;

        do {
            System.out.println("---Menu de opciones---");
            System.out.println("1.Ingresar pedido.");
            System.out.println("2.Procesar pago.");
            System.out.println("3.Salir");
            System.out.println("ingrese una opcion:");
            op = sc.nextInt();
            sc.nextLine();

            switch (op) {
                case 1:
                    System.out.println("ingrese la descripcion:");
                    pedido.setDescripcion(sc.nextLine());
                    System.out.println("ingrese el monto:");
                    pedido.setMonto(sc.nextDouble());
                    sc.nextLine();
                    break;
                case 2:
                    //siempre paga con PayPal, no hay forma de cambiarlo
                    //sin tocar el codigo de PagoService
                    PagoService servicio = new PagoService();
                    servicio.procesarPago(pedido);
                    break;
                case 3:
                    System.out.println("saliendo del programa....");
                    break;
                default:
                    System.out.println("opcion incorrecta...");
            }

        } while (op != 3);
    }

}
