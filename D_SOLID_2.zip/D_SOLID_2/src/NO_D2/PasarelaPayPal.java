package NO_D2;

public class PasarelaPayPal {
    public void pagar(Pedido pedido) {
        System.out.println("Pagando " + pedido.getMonto()
                + " con PayPal, pedido: " + pedido.getDescripcion());
    }
}
