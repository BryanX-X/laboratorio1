package d2_solid;

public class Pedido {
    private String descripcion;
    private double monto;

    public Pedido(String descripcion, double monto) {
        this.descripcion = descripcion;
        this.monto = monto;
    }

    public Pedido() {
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }
}
