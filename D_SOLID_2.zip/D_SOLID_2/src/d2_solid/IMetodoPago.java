package d2_solid;

//Abstraccion de la que depende PagoService, en lugar de una clase concreta.
public interface IMetodoPago {
    void pagar(Pedido pedido);
}
