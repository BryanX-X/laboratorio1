package d2_solid;

import java.util.Scanner;

public class D_SOLID_2 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Pedido pedido = new Pedido();
        int op;

        do {
            System.out.println("---Menu de opciones---");
            System.out.println("1.Ingresar pedido.");
            System.out.println("2.Pagar con PayPal.");
            System.out.println("3.Pagar con Tarjeta.");
            System.out.println("4.Salir");
            System.out.println("ingrese una opcion:");
            op = sc.nextInt();
            sc.nextLine();

            switch (op) {
                case 1:
                    System.out.println("ingrese la descripcion:");
                    pedido.setDescripcion(sc.nextLine());
                    System.out.println("ingrese el monto:");
                    pedido.setMonto(sc.nextDouble());
                    sc.nextLine();
                    break;
                case 2:
                    IMetodoPago paypal = new PasarelaPayPal();
                    PagoService servicioPayPal = new PagoService(paypal);
                    servicioPayPal.procesarPago(pedido);
                    break;
                case 3:
                    IMetodoPago tarjeta = new PasarelaTarjeta();
                    PagoService servicioTarjeta = new PagoService(tarjeta);
                    servicioTarjeta.procesarPago(pedido);
                    break;
                case 4:
                    System.out.println("saliendo del programa....");
                    break;
                default:
                    System.out.println("opcion incorrecta...");
            }

        } while (op != 4);
    }

}
