package d2_solid;

//otra clase de bajo nivel, se agrega sin tocar PagoService
public class PasarelaTarjeta implements IMetodoPago {
    @Override
    public void pagar(Pedido pedido) {
        System.out.println("Pagando " + pedido.getMonto()
                + " con Tarjeta, pedido: " + pedido.getDescripcion());
    }
}
