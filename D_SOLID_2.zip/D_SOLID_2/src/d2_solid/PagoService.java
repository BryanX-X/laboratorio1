package d2_solid;

public class PagoService {
    private IMetodoPago metodoPago;

    //el metodo de pago se inyecta desde afuera: PagoService no depende
    //de una pasarela concreta, sino de la abstraccion IMetodoPago
    public PagoService(IMetodoPago metodoPago) {
        this.metodoPago = metodoPago;
    }

    public void procesarPago(Pedido pedido) {
        metodoPago.pagar(pedido);
    }
}
