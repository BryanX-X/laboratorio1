package d2_solid;

//clase de bajo nivel
public class PasarelaPayPal implements IMetodoPago {
    @Override
    public void pagar(Pedido pedido) {
        System.out.println("Pagando " + pedido.getMonto()
                + " con PayPal, pedido: " + pedido.getDescripcion());
    }
}
