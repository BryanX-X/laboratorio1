package NO_O;

import java.util.Scanner;

public class NO_O {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Empleado empleado = new Empleado();
        EmpleadoService servicio = new EmpleadoService();

        int op;

        do {
            System.out.println("---Menu de opciones---");
            System.out.println("1.Ingresar empleado.");
            System.out.println("2.Calcular bono.");
            System.out.println("3.Salir");
            System.out.println("ingrese una opcion:");
            op = sc.nextInt();
            sc.nextLine();

            switch (op) {
                case 1:
                    System.out.println("ingrese el nombre:");
                    empleado.setNombre(sc.nextLine());
                    System.out.println("ingrese el departamento:");
                    empleado.setDepartamento(sc.nextLine());
                    System.out.println("ingrese el tipo (DOCENTE/ADMINISTRATIVO):");
                    empleado.setTipo(sc.nextLine());
                    System.out.println("ingrese el sueldo base:");
                    empleado.setSueldoBase(sc.nextDouble());
                    sc.nextLine();
                    break;
                case 2:
                    System.out.println("Bono calculado: " + servicio.calcularBono(empleado));
                    break;
                case 3:
                    System.out.println("saliendo del programa....");
                    break;
                default:
                    System.out.println("opcion incorrecta...");
            }

        } while (op != 3);
    }

}
