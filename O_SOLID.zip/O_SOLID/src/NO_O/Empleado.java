package NO_O;

public class Empleado {
    private String nombre, departamento, tipo;
    private double sueldoBase;

    public Empleado(String nombre, String departamento, String tipo, double sueldoBase) {
        this.nombre = nombre;
        this.departamento = departamento;
        this.tipo = tipo;
        this.sueldoBase = sueldoBase;
    }

    public Empleado() {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public double getSueldoBase() {
        return sueldoBase;
    }

    public void setSueldoBase(double sueldoBase) {
        this.sueldoBase = sueldoBase;
    }
}
