package NO_O;

public class EmpleadoService {

    //cerebro del ejercicio: si se agrega un tipo de empleado nuevo
    //hay que MODIFICAR este metodo (viola OCP)
    public double calcularBono(Empleado empleado) {
        if (empleado.getTipo().equalsIgnoreCase("DOCENTE")) {
            return empleado.getSueldoBase() * 0.20;
        } else if (empleado.getTipo().equalsIgnoreCase("ADMINISTRATIVO")) {
            return empleado.getSueldoBase() * 0.10;
        } else {
            return 0;
        }
        //si mañana aparece "PRACTICANTE" hay que venir aquí a agregar otro else if...
    }
}
