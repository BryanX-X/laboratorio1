package o_solid;

public class Docente extends Empleado {

    @Override
    public double calcularBono() {
        return sueldoBase * 0.20;
    }
}
