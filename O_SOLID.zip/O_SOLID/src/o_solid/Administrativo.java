package o_solid;

public class Administrativo extends Empleado {

    @Override
    public double calcularBono() {
        return sueldoBase * 0.10;
    }
}
