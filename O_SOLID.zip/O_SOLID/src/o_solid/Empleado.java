package o_solid;

public abstract class Empleado {
    protected String nombre, departamento;
    protected double sueldoBase;

    public Empleado(String nombre, String departamento, double sueldoBase) {
        this.nombre = nombre;
        this.departamento = departamento;
        this.sueldoBase = sueldoBase;
    }

    public Empleado() {
    }

    public abstract double calcularBono();

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public double getSueldoBase() {
        return sueldoBase;
    }

    public void setSueldoBase(double sueldoBase) {
        this.sueldoBase = sueldoBase;
    }
}
