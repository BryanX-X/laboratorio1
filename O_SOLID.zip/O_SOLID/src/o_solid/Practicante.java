package o_solid;

//Este tipo se agrega despues, y NO fue necesario tocar EmpleadoService.
//Eso es justamente estar "abierto a extension, cerrado a modificacion".
public class Practicante extends Empleado {

    @Override
    public double calcularBono() {
        return sueldoBase * 0.05;
    }
}
