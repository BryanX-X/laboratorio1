package o_solid;

public class EmpleadoService {

    //esta clase NUNCA se vuelve a tocar aunque aparezcan nuevos tipos de empleado
    public double procesarBono(Empleado empleado) {
        return empleado.calcularBono();
    }
}
