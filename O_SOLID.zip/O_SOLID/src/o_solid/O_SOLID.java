package o_solid;

import java.util.Scanner;

public class O_SOLID {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Docente docente = new Docente();
        Administrativo adm = new Administrativo();
        Practicante practicante = new Practicante();

        EmpleadoService servicio = new EmpleadoService();

        int op;

        do {
            System.out.println("---Menu de opciones---");
            System.out.println("1.Ingresar Docente.");
            System.out.println("2.Ingresar Administrativo.");
            System.out.println("3.Ingresar Practicante.");
            System.out.println("4.Calcular bono docente.");
            System.out.println("5.Calcular bono administrativo.");
            System.out.println("6.Calcular bono practicante.");
            System.out.println("7.Salir");
            System.out.println("ingrese una opcion:");
            op = sc.nextInt();
            sc.nextLine();

            switch (op) {
                case 1:
                    System.out.println("ingrese el nombre:");
                    docente.setNombre(sc.nextLine());
                    System.out.println("ingrese el departamento:");
                    docente.setDepartamento(sc.nextLine());
                    System.out.println("ingrese el sueldo base:");
                    docente.setSueldoBase(sc.nextDouble());
                    sc.nextLine();
                    break;
                case 2:
                    System.out.println("ingrese el nombre:");
                    adm.setNombre(sc.nextLine());
                    System.out.println("ingrese el departamento:");
                    adm.setDepartamento(sc.nextLine());
                    System.out.println("ingrese el sueldo base:");
                    adm.setSueldoBase(sc.nextDouble());
                    sc.nextLine();
                    break;
                case 3:
                    System.out.println("ingrese el nombre:");
                    practicante.setNombre(sc.nextLine());
                    System.out.println("ingrese el departamento:");
                    practicante.setDepartamento(sc.nextLine());
                    System.out.println("ingrese el sueldo base:");
                    practicante.setSueldoBase(sc.nextDouble());
                    sc.nextLine();
                    break;
                case 4:
                    System.out.println("Bono docente: " + servicio.procesarBono(docente));
                    break;
                case 5:
                    System.out.println("Bono administrativo: " + servicio.procesarBono(adm));
                    break;
                case 6:
                    System.out.println("Bono practicante: " + servicio.procesarBono(practicante));
                    break;
                case 7:
                    System.out.println("saliendo del programa....");
                    break;
                default:
                    System.out.println("opcion incorrecta...");
            }

        } while (op != 7);
    }

}
