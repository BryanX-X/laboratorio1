package s_solid;

public class EmpleadoService {
    //esta clase SOLO se encarga de calcular el sueldo

    public double calcularSueldo(Empleado empleado) {
        return empleado.getSueldoBase() * 1.10; // le suma un 10% de bono
    }
}
