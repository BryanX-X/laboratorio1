package s_solid;

public class EmpleadoRepositorio {
    //esta clase SOLO se encarga de guardar el empleado

    public void guardar(Empleado empleado) {
        System.out.println("Guardando empleado " + empleado.getNombre()
                + " en la base de datos...");
    }
}
