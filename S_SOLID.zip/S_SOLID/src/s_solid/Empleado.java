package s_solid;

public class Empleado {
    private String nombre, departamento;
    private double sueldoBase;

    public Empleado(String nombre, String departamento, double sueldoBase) {
        this.nombre = nombre;
        this.departamento = departamento;
        this.sueldoBase = sueldoBase;
    }

    public Empleado() {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public double getSueldoBase() {
        return sueldoBase;
    }

    public void setSueldoBase(double sueldoBase) {
        this.sueldoBase = sueldoBase;
    }
}
