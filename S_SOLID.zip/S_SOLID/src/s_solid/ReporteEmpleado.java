package s_solid;

public class ReporteEmpleado {
    //esta clase SOLO se encarga de mostrar el reporte

    public void mostrarReporte(Empleado empleado, double sueldoFinal) {
        System.out.println("===REPORTE===");
        System.out.println("Nombre: " + empleado.getNombre());
        System.out.println("Departamento: " + empleado.getDepartamento());
        System.out.println("Sueldo final: " + sueldoFinal);
    }
}
