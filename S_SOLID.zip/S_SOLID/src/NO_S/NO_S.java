package NO_S;

import java.util.Scanner;

public class NO_S {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Empleado empleado = new Empleado();
        EmpleadoService servicio = new EmpleadoService();

        int op;

        do {
            System.out.println("---Menu de opciones---");
            System.out.println("1.Ingresar empleado.");
            System.out.println("2.Calcular sueldo.");
            System.out.println("3.Guardar en base de datos.");
            System.out.println("4.Mostrar reporte.");
            System.out.println("5.Salir");
            System.out.println("ingrese una opcion:");
            op = sc.nextInt();
            sc.nextLine();

            switch (op) {
                case 1:
                    System.out.println("ingrese el nombre:");
                    empleado.setNombre(sc.nextLine());
                    System.out.println("ingrese el departamento:");
                    empleado.setDepartamento(sc.nextLine());
                    System.out.println("ingrese el sueldo base:");
                    empleado.setSueldoBase(sc.nextDouble());
                    sc.nextLine();
                    break;
                case 2:
                    System.out.println("Sueldo calculado: " + servicio.calcularSueldo(empleado));
                    break;
                case 3:
                    servicio.guardar(empleado);
                    break;
                case 4:
                    servicio.imprimirReporte(empleado);
                    break;
                case 5:
                    System.out.println("saliendo del programa....");
                    break;
                default:
                    System.out.println("opcion incorrecta...");
            }

        } while (op != 5);
    }

}
