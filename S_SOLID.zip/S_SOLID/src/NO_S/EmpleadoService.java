package NO_S;

public class EmpleadoService {

    //cerebro del ejercicio: esta clase tiene MAS DE UNA razon para cambiar
    //(calcula sueldo, guarda en base de datos e imprime reporte)

    public double calcularSueldo(Empleado empleado) {
        return empleado.getSueldoBase() * 1.10; // le suma un 10% de bono
    }

    public void guardar(Empleado empleado) {
        System.out.println("Guardando empleado " + empleado.getNombre()
                + " en la base de datos...");
    }

    public void imprimirReporte(Empleado empleado) {
        System.out.println("===REPORTE===");
        System.out.println("Nombre: " + empleado.getNombre());
        System.out.println("Departamento: " + empleado.getDepartamento());
        System.out.println("Sueldo final: " + calcularSueldo(empleado));
    }
}
